import solution
def test_0():
	assert solution.Solution().numberOfGoodSubarraySplits(nums = [0, 1, 0, 0, 1]) == 3