import solution
def test_1():
	assert solution.Solution().numberOfGoodSubarraySplits(nums = [0, 1, 0]) == 1