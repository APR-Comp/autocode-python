import solution

def test_3():
	assert solution.Solution().maxStrength(nums = [1,2]) == 2