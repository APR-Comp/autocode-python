
import solution

def test_2879():
	assert solution.Solution().maxStrength([872, -8, -1]) == 6976
