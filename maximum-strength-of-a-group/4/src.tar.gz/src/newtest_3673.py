
import solution

def test_3673():
	assert solution.Solution().maxStrength([60, -7]) == 60
