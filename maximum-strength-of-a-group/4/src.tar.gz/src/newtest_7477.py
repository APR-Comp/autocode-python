
import solution

def test_7477():
	assert solution.Solution().maxStrength([-1]) == -1
