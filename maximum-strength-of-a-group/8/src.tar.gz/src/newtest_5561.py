
import solution

def test_5561():
	assert solution.Solution().maxStrength([8]) == 8
