
import solution

def test_9133():
	assert solution.Solution().maxStrength([-154, -2, 6, 1]) == 1848
