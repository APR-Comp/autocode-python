import solution

def test_1():
	assert solution.Solution().maxStrength(nums = [-4,-5,-4]) == 20