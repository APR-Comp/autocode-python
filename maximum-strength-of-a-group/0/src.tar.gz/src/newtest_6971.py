
import solution

def test_6971():
	assert solution.Solution().maxStrength([1]) == 1
