import solution

def test_0():
	assert solution.Solution().maxStrength(nums = [3,-1,-5,2,5,-9]) == 1350