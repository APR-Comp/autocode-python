import solution

def test_4():
	assert solution.Solution().maxStrength(nums = [0]) == 0