
import solution

def test_7688():
	assert solution.Solution().maxStrength([25]) == 25
