
import solution

def test_4731():
	assert solution.Solution().maxStrength([45]) == 45
