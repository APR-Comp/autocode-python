
import solution

def test_9993():
	assert solution.Solution().maxStrength([62, 3, 38]) == 7068
