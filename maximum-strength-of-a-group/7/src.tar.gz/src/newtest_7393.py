
import solution

def test_7393():
	assert solution.Solution().maxStrength([8]) == 8
