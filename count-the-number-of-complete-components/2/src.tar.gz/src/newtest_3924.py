
import solution

def test_3924():
	assert solution.Solution().countCompleteComponents(7,[[2, 1]]) == 6
