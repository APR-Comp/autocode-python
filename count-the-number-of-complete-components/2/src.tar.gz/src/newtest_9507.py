
import solution

def test_9507():
	assert solution.Solution().countCompleteComponents(50,[[17, 3]]) == 49
