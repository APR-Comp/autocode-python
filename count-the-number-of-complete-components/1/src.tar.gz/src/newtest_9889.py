
import solution

def test_9889():
	assert solution.Solution().countCompleteComponents(7,[[2, 6], [4, 4]]) == 5
