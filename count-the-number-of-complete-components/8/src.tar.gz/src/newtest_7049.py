
import solution

def test_7049():
	assert solution.Solution().countCompleteComponents(47,[[5, 43]]) == 46
