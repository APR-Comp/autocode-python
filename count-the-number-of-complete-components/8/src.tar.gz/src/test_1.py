import solution

def test_1():
	assert solution.Solution().countCompleteComponents(n = 6, edges = [[0,1],[0,2],[1,2],[3,4],[3,5]]) == 1