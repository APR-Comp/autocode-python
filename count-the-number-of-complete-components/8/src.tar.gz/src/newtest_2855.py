
import solution

def test_2855():
	assert solution.Solution().countCompleteComponents(41,[[20, 1], [36, 1]]) == 38
