
import solution

def test_9705():
	assert solution.Solution().countCompleteComponents(3,[[2, 2], [0, 2], [0, 0]]) == 1
