
import solution

def test_4036():
	assert solution.Solution().countCompleteComponents(12,[[9, 7], [3, 3]]) == 10
