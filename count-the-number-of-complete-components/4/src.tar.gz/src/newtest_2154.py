
import solution

def test_2154():
	assert solution.Solution().countCompleteComponents(6,[[3, 1], [2, 2]]) == 4
