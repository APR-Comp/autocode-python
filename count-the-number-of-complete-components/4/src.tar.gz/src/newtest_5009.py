
import solution

def test_5009():
	assert solution.Solution().countCompleteComponents(8,[[3, 4]]) == 7
