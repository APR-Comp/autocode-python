
import solution

def test_2226():
	assert solution.Solution().countCompleteComponents(5,[[1, 3]]) == 4
