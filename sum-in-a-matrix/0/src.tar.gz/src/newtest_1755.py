
import solution

def test_1755():
	assert solution.Solution().matrixSum([[62, 898, 814, 689, 720], [14, 33, 75, 64, 6]]) == 3183
