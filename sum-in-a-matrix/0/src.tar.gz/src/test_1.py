import solution

def test_1():
	assert solution.Solution().matrixSum(nums = [[1]]) == 1