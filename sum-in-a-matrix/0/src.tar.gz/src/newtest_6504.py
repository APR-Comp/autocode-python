
import solution

def test_6504():
	assert solution.Solution().matrixSum([[98, 723], [69, 958], [40, 24], [5, 938]]) == 1056
