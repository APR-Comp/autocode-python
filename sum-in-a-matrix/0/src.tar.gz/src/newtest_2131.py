
import solution

def test_2131():
	assert solution.Solution().matrixSum([[26, 64, 1, 10, 5, 9], [47, 3, 80, 651, 699, 453]]) == 1933
