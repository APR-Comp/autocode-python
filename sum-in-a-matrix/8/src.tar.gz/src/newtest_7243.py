
import solution

def test_7243():
	assert solution.Solution().matrixSum([[61, 72, 33], [13, 17, 91], [4, 53, 766]]) == 860
