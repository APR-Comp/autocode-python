
import solution

def test_3838():
	assert solution.Solution().matrixSum([[76, 138], [67, 9], [7, 57]]) == 214
