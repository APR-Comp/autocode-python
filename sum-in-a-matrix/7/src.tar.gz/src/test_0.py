import solution

def test_0():
	assert solution.Solution().matrixSum(nums = [[7,2,1],[6,4,2],[6,5,3],[3,2,1]]) == 15