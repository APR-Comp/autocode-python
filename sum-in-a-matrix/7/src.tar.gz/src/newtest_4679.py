
import solution

def test_4679():
	assert solution.Solution().matrixSum([[58, 41, 186], [5, 461, 672], [1, 368, 787], [5, 7, 25], [3, 72, 593], [2, 821, 47], [6, 153, 40], [8, 890, 350]]) == 1392
