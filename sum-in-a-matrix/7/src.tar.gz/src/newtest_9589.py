
import solution

def test_9589():
	assert solution.Solution().matrixSum([[5, 84, 68], [2, 8, 911]]) == 984
