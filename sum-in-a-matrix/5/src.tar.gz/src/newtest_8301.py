
import solution

def test_8301():
	assert solution.Solution().matrixSum([[5, 4, 4], [7, 619, 54], [6, 7, 516]]) == 680
