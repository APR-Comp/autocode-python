
import solution

def test_2082():
	assert solution.Solution().matrixSum([[20, 481], [4, 530], [74, 7]]) == 550
