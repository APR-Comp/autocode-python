
import solution

def test_8206():
	assert solution.Solution().matrixSum([[5, 420], [44, 78]]) == 464
