
import solution

def test_1736():
	assert solution.Solution().colorTheArray(7,[(2, 7), (1, 9), (1, 2)]) == [0, 0, 0]
