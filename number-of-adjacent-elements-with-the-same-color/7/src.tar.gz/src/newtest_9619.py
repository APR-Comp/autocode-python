
import solution

def test_9619():
	assert solution.Solution().colorTheArray(4,[(2, 3), (0, 75)]) == [0, 0]
