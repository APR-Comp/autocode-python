import solution

def test_0():
	assert solution.Solution().colorTheArray(n = 4, queries = [[0,2],[1,2],[3,1],[1,1],[2,1]]) == [0,1,1,0,2]