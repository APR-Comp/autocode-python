
import solution

def test_993():
	assert solution.Solution().colorTheArray(1,[(0, 9), (0, 4), (0, 70)]) == [0, 0, 0]
