import solution

def test_1():
	assert solution.Solution().colorTheArray(n = 1, queries = [[0,100000]]) == [0]