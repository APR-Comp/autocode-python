
import solution

def test_3386():
	assert solution.Solution().colorTheArray(7,[(1, 5), (3, 9)]) == [0, 0]
