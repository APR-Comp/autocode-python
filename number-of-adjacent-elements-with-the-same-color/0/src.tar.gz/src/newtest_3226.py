
import solution

def test_3226():
	assert solution.Solution().colorTheArray(8,[(7, 46), (0, 96), (3, 2), (1, 5), (4, 2), (2, 4)]) == [0, 0, 0, 0, 1, 1]
