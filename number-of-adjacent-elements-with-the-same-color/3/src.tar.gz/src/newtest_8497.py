
import solution

def test_8497():
	assert solution.Solution().colorTheArray(22,[(12, 92), (4, 5)]) == [0, 0]
