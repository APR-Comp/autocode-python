
import solution

def test_492():
	assert solution.Solution().colorTheArray(1,[(0, 84), (0, 6)]) == [0, 0]
