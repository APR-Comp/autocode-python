
import solution

def test_7194():
	assert solution.Solution().colorTheArray(40,[(1, 2), (35, 86)]) == [0, 0]
