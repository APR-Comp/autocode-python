
import solution

def test_6596():
	assert solution.Solution().colorTheArray(33,[(26, 79), (8, 4)]) == [0, 0]
