
import solution

def test_1224():
	assert solution.Solution().colorTheArray(48,[(7, 3), (8, 6)]) == [0, 0]
