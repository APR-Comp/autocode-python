
import solution

def test_656():
	assert solution.Solution().distanceTraveled(4,91) == 40
