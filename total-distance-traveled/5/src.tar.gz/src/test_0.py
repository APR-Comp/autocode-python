import solution

def test_0():
	assert solution.Solution().distanceTraveled(mainTank = 5, additionalTank = 10) == 60