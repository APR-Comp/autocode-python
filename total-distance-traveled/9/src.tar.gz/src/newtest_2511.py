
import solution

def test_2511():
	assert solution.Solution().distanceTraveled(15,913) == 180
