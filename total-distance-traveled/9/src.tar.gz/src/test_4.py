import solution

def test_4():
	assert solution.Solution().distanceTraveled(mainTank = 6, additionalTank = 1) == 70