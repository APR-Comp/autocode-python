
import solution

def test_2720():
	assert solution.Solution().distanceTraveled(474,51) == 5250
