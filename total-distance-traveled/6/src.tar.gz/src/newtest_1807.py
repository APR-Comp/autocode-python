
import solution

def test_1807():
	assert solution.Solution().distanceTraveled(38,302) == 470
