
import solution

def test_6693():
	assert solution.Solution().distanceTraveled(43,55) == 530
