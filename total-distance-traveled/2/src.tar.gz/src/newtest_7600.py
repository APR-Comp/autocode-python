
import solution

def test_7600():
	assert solution.Solution().distanceTraveled(47,4) == 510
