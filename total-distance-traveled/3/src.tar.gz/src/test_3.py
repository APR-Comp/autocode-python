import solution

def test_3():
	assert solution.Solution().distanceTraveled(mainTank = 1, additionalTank = 0) == 10