
import solution

def test_4875():
	assert solution.Solution().distanceTraveled(568,40) == 6080
