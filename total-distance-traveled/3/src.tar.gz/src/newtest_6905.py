
import solution

def test_6905():
	assert solution.Solution().distanceTraveled(30,40) == 370
