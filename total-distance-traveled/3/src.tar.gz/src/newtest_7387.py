
import solution

def test_7387():
	assert solution.Solution().distanceTraveled(24,9) == 290
