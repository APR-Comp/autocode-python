import solution

def test_1():
	assert solution.Solution().distanceTraveled(mainTank = 1, additionalTank = 2) == 10