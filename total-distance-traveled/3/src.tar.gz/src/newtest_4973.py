
import solution

def test_4973():
	assert solution.Solution().distanceTraveled(28,27) == 340
