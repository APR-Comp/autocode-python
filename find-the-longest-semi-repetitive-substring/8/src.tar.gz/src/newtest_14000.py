
import solution

def test_14000():
	assert solution.Solution().longestSemiRepetitiveSubstring("3") == 1
