
import solution

def test_53691():
	assert solution.Solution().longestSemiRepetitiveSubstring("3438") == 4
