
import solution

def test_42789():
	assert solution.Solution().longestSemiRepetitiveSubstring("2") == 1
