
import solution

def test_16938():
	assert solution.Solution().longestSemiRepetitiveSubstring("4") == 1
