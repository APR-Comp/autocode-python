import solution

def test_0():
	assert solution.Solution().longestSemiRepetitiveSubstring(s = "52233") == 4