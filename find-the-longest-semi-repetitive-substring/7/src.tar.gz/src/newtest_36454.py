
import solution

def test_36454():
	assert solution.Solution().longestSemiRepetitiveSubstring("5") == 1
