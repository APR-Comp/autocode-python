import solution

def test_3():
	assert solution.Solution().longestSemiRepetitiveSubstring(s = "123") == 3