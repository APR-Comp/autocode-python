import solution

def test_1():
	assert solution.Solution().longestSemiRepetitiveSubstring(s = "5494") == 4