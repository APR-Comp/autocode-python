
import solution

def test_68404():
	assert solution.Solution().longestSemiRepetitiveSubstring("2") == 1
