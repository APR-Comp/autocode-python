
import solution

def test_80063():
	assert solution.Solution().longestSemiRepetitiveSubstring("1") == 1
