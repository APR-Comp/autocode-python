import solution

def test_2():
	assert solution.Solution().longestSemiRepetitiveSubstring(s = "1111111") == 2