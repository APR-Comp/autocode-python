
import solution

def test_49239():
	assert solution.Solution().longestSemiRepetitiveSubstring("51") == 2
