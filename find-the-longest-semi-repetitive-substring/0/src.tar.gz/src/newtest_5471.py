
import solution

def test_5471():
	assert solution.Solution().longestSemiRepetitiveSubstring("679") == 3
