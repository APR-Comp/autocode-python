
import solution

def test_19805():
	assert solution.Solution().longestSemiRepetitiveSubstring("91") == 2
