
import solution

def test_8137():
	assert solution.Solution().semiOrderedPermutation([7, 32, 18, 13, 34, 30, 4, 26, 17, 33, 28, 31, 22, 23, 6, 1, 29, 5, 27, 15, 12, 19, 21, 10, 9, 24, 8, 11, 16, 20, 2, 25, 14, 3]) == 43
