
import solution

def test_7333():
	assert solution.Solution().semiOrderedPermutation([8, 2, 9, 3, 1, 7, 11, 10, 5, 6, 4]) == 8
