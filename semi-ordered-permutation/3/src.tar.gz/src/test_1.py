import solution

def test_1():
	assert solution.Solution().semiOrderedPermutation(nums = [2,4,1,3]) == 3