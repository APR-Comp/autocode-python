import solution

def test_0():
	assert solution.Solution().semiOrderedPermutation(nums = [2,1,4,3]) == 2