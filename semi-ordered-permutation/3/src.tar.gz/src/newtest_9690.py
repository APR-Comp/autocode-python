
import solution

def test_9690():
	assert solution.Solution().semiOrderedPermutation([3, 2, 4, 1]) == 3
