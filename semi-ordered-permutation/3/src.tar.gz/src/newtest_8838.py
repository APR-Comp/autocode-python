
import solution

def test_8838():
	assert solution.Solution().semiOrderedPermutation([23, 11, 35, 5, 6, 19, 37, 10, 18, 15, 34, 32, 24, 12, 1, 21, 27, 8, 14, 4, 7, 16, 26, 3, 13, 29, 17, 33, 30, 22, 9, 36, 25, 2, 28, 31, 20]) == 43
