import solution

def test_2():
	assert solution.Solution().semiOrderedPermutation(nums = [1,3,4,2,5]) == 0