
import solution

def test_7218():
	assert solution.Solution().semiOrderedPermutation([7, 5, 4, 1, 2, 3, 6]) == 8
