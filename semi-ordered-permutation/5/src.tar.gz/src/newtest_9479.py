
import solution

def test_9479():
	assert solution.Solution().semiOrderedPermutation([1, 3, 9, 5, 8, 2, 6, 4, 7]) == 6
