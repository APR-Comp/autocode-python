
import solution

def test_4163():
	assert solution.Solution().semiOrderedPermutation([8, 5, 1, 7, 3, 6, 2, 4]) == 8
