
import solution

def test_4809():
	assert solution.Solution().semiOrderedPermutation([1, 7, 4, 6, 2, 3, 5]) == 5
