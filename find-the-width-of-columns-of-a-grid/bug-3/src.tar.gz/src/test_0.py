import solution
def test_0():
	assert solution.Solution().findColumnWidth(grid = [[1], [22], [333]]) == [3]