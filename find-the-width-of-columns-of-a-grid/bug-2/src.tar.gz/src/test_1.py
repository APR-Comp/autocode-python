import solution
def test_1():
	assert solution.Solution().findColumnWidth(grid = [[-15, 1, 3], [15, 7, 12], [5, 6, -2]]) == [3, 1, 2]