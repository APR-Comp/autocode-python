import solution
def test_1():
	assert solution.Solution().findPrimePairs(n = 2) == []