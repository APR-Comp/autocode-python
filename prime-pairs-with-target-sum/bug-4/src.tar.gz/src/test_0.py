import solution
def test_0():
	assert solution.Solution().findPrimePairs(n = 10) == [[3, 7], [5, 5]]