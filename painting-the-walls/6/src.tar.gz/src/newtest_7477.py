
import solution

def test_7477():
	assert solution.Solution().paintWalls([7, 1188, 5849],[4, 330, 78]) == 7
