import solution

def test_2():
	assert solution.Solution().paintWalls(cost = [2], time = [1]) == 2