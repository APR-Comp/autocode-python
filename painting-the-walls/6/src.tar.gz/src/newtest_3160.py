
import solution

def test_3160():
	assert solution.Solution().paintWalls([383, 7, 716],[4, 401, 417]) == 7
