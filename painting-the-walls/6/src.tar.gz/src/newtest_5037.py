
import solution

def test_5037():
	assert solution.Solution().paintWalls([46, 4, 2],[46, 325, 334]) == 2
