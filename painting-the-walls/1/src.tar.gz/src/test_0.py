import solution

def test_0():
	assert solution.Solution().paintWalls(cost = [1,2,3,2], time = [1,2,3,2]) == 3