
import solution

def test_9548():
	assert solution.Solution().paintWalls([4587, 759, 6],[4, 231, 382]) == 6
