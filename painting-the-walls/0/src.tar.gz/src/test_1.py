import solution

def test_1():
	assert solution.Solution().paintWalls(cost = [2,3,4,2], time = [1,1,1,1]) == 4