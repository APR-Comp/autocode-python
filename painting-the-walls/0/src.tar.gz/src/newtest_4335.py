
import solution

def test_4335():
	assert solution.Solution().paintWalls([22962, 7521],[6, 9]) == 7521
