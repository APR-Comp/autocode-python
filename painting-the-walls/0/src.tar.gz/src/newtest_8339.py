
import solution

def test_8339():
	assert solution.Solution().paintWalls([59, 57, 1],[24, 4, 407]) == 1
