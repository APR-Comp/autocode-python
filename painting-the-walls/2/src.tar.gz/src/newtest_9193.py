
import solution

def test_9193():
	assert solution.Solution().paintWalls([9],[445]) == 9
