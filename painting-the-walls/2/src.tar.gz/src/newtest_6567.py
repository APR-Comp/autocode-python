
import solution

def test_6567():
	assert solution.Solution().paintWalls([16, 160, 2661, 1805, 3225],[19, 6, 13, 9, 6]) == 16
