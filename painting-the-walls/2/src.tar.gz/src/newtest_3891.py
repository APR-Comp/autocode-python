
import solution

def test_3891():
	assert solution.Solution().paintWalls([7, 1, 536],[3, 7, 5]) == 1
