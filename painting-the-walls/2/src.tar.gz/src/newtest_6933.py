
import solution

def test_6933():
	assert solution.Solution().paintWalls([2, 2428, 7751],[9, 3, 3]) == 2
