import solution
def test_2():
	assert solution.Solution().isWinner(player1 = [2, 3], player2 = [4, 1]) == 0