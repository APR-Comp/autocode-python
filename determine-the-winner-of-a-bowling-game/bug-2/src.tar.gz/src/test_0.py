import solution
def test_0():
	assert solution.Solution().isWinner(player1 = [4, 10, 7, 9], player2 = [6, 5, 2, 3]) == 1