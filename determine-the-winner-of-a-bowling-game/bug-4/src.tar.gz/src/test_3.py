import solution
def test_3():
	assert solution.Solution().isWinner(player1 = [10, 2, 2, 3], player2 = [3, 8, 4, 5]) == 1