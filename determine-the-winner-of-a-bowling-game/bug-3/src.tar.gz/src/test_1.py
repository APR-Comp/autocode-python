import solution
def test_1():
	assert solution.Solution().isWinner(player1 = [3, 5, 7, 6], player2 = [8, 10, 10, 2]) == 2