import solution

def test_1():
	assert solution.Solution().findValueOfPartition(nums = [100,1,10]) == 9