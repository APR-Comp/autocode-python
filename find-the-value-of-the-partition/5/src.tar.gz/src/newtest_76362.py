
import solution

def test_76362():
	assert solution.Solution().findValueOfPartition([9, 763, 14452]) == 754
