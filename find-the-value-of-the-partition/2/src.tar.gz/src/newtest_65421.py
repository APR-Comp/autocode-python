
import solution

def test_65421():
	assert solution.Solution().findValueOfPartition([352, 59753, 641656]) == 59401
