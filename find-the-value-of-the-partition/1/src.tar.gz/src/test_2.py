import solution

def test_2():
	assert solution.Solution().findValueOfPartition(nums = [1,2]) == 1