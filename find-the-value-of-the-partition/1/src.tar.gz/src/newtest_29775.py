
import solution

def test_29775():
	assert solution.Solution().findValueOfPartition([5, 67, 266, 763]) == 62
