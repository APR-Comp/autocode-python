
import solution

def test_28843():
	assert solution.Solution().findValueOfPartition([484, 5770]) == 5286
