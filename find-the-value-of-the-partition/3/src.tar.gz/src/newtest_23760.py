
import solution

def test_23760():
	assert solution.Solution().findValueOfPartition([3, 9]) == 6
