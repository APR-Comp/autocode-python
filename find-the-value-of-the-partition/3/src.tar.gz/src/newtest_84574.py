
import solution

def test_84574():
	assert solution.Solution().findValueOfPartition([7, 9, 865, 912645]) == 2
