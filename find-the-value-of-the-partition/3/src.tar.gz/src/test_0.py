import solution

def test_0():
	assert solution.Solution().findValueOfPartition(nums = [1,3,2,4]) == 1