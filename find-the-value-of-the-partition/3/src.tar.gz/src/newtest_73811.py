
import solution

def test_73811():
	assert solution.Solution().findValueOfPartition([5, 348, 6664, 70916]) == 343
