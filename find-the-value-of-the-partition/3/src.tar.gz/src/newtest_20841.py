
import solution

def test_20841():
	assert solution.Solution().findValueOfPartition([3, 3, 8, 374, 901]) == 0
