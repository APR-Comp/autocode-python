
import solution

def test_19538():
	assert solution.Solution().findValueOfPartition([5, 59]) == 54
