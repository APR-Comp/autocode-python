
import solution

def test_51191():
	assert solution.Solution().findValueOfPartition([4, 60, 805]) == 56
