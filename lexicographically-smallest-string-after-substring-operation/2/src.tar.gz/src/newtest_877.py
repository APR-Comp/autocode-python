
import solution

def test_877():
	assert solution.Solution().smallestString("t") == "s"
