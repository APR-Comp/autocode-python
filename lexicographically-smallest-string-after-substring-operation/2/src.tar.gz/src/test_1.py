import solution

def test_1():
	assert solution.Solution().smallestString(s = "acbbc") == "abaab"