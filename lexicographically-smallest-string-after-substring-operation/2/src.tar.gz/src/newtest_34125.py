
import solution

def test_34125():
	assert solution.Solution().smallestString("b") == "a"
