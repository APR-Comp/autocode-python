
import solution

def test_26924():
	assert solution.Solution().smallestString("x") == "w"
