import solution

def test_5():
	assert solution.Solution().smallestString(s = "b") == "a"