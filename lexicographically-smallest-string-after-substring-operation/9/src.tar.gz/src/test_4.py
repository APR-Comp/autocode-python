import solution

def test_4():
	assert solution.Solution().smallestString(s = "z") == "y"