
import solution

def test_7860():
	assert solution.Solution().smallestString("apt") == "aos"
