
import solution

def test_38827():
	assert solution.Solution().smallestString("toato") == "snato"
