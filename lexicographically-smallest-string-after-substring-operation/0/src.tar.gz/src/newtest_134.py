
import solution

def test_134():
	assert solution.Solution().smallestString("t") == "s"
