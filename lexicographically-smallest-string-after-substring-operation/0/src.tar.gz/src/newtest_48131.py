
import solution

def test_48131():
	assert solution.Solution().smallestString("z") == "y"
