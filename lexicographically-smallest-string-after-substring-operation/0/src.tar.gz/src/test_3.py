import solution

def test_3():
	assert solution.Solution().smallestString(s = "a") == "z"