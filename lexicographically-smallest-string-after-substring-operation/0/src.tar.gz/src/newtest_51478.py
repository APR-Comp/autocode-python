
import solution

def test_51478():
	assert solution.Solution().smallestString("v") == "u"
