
import solution

def test_61913():
	assert solution.Solution().smallestString("qk") == "pj"
