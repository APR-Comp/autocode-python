import solution

def test_0():
	assert solution.Solution().smallestString(s = "cbabc") == "baabc"