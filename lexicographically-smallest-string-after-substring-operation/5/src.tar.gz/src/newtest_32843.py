
import solution

def test_32843():
	assert solution.Solution().smallestString("j") == "i"
