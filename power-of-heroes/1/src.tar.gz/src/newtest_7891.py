
import solution

def test_7891():
	assert solution.Solution().sumOfPower([4, 70]) == 362664
