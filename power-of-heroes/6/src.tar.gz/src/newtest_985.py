
import solution

def test_985():
	assert solution.Solution().sumOfPower([7]) == 343
