
import solution

def test_3746():
	assert solution.Solution().sumOfPower([77, 24, 60, 9, 7, 9, 4, 7]) == 6937048
