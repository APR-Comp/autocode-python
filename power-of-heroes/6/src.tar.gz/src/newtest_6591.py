
import solution

def test_6591():
	assert solution.Solution().sumOfPower([6362, 6, 66]) == 659595388
