
import solution

def test_9193():
	assert solution.Solution().sumOfPower([1, 7, 6]) == 988
