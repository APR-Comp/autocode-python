
import solution

def test_4090():
	assert solution.Solution().sumOfPower([3]) == 27
