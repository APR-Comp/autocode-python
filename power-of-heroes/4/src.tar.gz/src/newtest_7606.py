
import solution

def test_7606():
	assert solution.Solution().sumOfPower([128]) == 2097152
