
import solution

def test_24():
	assert solution.Solution().sumOfPower([5415, 78706]) == 619590332
