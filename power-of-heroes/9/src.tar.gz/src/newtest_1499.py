
import solution

def test_1499():
	assert solution.Solution().sumOfPower([865]) == 647214625
