
import solution

def test_7101():
	assert solution.Solution().sumOfPower([8, 9, 329969, 7, 9]) == 147003802
