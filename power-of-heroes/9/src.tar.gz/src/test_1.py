import solution

def test_1():
	assert solution.Solution().sumOfPower(nums = [1,1,1]) == 7