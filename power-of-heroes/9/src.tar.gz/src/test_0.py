import solution

def test_0():
	assert solution.Solution().sumOfPower(nums = [2,1,4]) == 141