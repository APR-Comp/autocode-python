
import solution

def test_6884():
	assert solution.Solution().differenceOfDistinctValues([[0], [0]]) == [[0], [0]]
