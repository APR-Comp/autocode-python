
import solution

def test_3699():
	assert solution.Solution().differenceOfDistinctValues([[0], [0]]) == [[0], [0]]
