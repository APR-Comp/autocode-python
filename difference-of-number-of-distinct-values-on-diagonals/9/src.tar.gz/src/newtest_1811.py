
import solution

def test_1811():
	assert solution.Solution().differenceOfDistinctValues([[2, 1, 0], [2, 0, 1], [1, 0, 2], [0, 1, 2]]) == [[2, 1, 0], [2, 0, 1], [1, 0, 2], [0, 1, 2]]
