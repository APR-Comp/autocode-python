
import solution

def test_2211():
	assert solution.Solution().differenceOfDistinctValues([[1, 1, 1, 0], [0, 1, 1, 1]]) == [[1, 1, 1, 0], [0, 1, 1, 1]]
