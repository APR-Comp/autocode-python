
import solution

def test_6105():
	assert solution.Solution().differenceOfDistinctValues([[2, 2, 1, 0], [1, 0, 0, 1], [0, 1, 2, 2]]) == [[2, 2, 1, 0], [1, 0, 0, 1], [0, 1, 2, 2]]
