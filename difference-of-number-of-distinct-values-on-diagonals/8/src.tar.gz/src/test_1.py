import solution

def test_1():
	assert solution.Solution().differenceOfDistinctValues(grid = [[1]]) == [[0]]