
import solution

def test_8197():
	assert solution.Solution().differenceOfDistinctValues([[1, 0], [0, 1]]) == [[1, 0], [0, 1]]
