import solution

def test_0():
	assert solution.Solution().differenceOfDistinctValues(grid = [[1,2,3],[3,1,5],[3,2,1]]) == [[1,1,0],[1,0,1],[0,1,1]]