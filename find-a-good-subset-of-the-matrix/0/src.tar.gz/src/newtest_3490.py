
import solution

def test_3490():
	assert solution.Solution().goodSubsetofBinaryMatrix([[1, 0], [0, 0]]) == [0, 1]
