
import solution

def test_8041():
	assert solution.Solution().goodSubsetofBinaryMatrix([[0, 0], [0, 0]]) == [0, 1]
