import solution

def test_3():
	assert solution.Solution().goodSubsetofBinaryMatrix(grid =[[0,0],[1,1],[1,0],[1,0]]) == [0,1]