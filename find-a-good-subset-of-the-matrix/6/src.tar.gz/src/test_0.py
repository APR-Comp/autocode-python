import solution

def test_0():
	assert solution.Solution().goodSubsetofBinaryMatrix(grid = [[0,1,1,0],[0,0,0,1],[1,1,1,1]]) == [0,1]