
import solution

def test_1419():
	assert solution.Solution().goodSubsetofBinaryMatrix([[0, 1, 0, 0, 1], [0, 0, 0, 0, 0]]) == [0, 1]
