
import solution

def test_2135():
	assert solution.Solution().goodSubsetofBinaryMatrix([[1, 0], [1, 1]]) == []
