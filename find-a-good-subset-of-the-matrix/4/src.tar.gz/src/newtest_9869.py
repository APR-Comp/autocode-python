
import solution

def test_9869():
	assert solution.Solution().goodSubsetofBinaryMatrix([[1, 0, 0], [0, 0, 0]]) == [0, 1]
