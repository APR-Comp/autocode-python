
import solution

def test_3801():
	assert solution.Solution().goodSubsetofBinaryMatrix([[1], [1]]) == []
