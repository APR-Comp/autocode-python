
import solution

def test_619():
	assert solution.Solution().minCost([97],341) == 97
