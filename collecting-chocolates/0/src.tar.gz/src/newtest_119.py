
import solution

def test_119():
	assert solution.Solution().minCost([1, 8],6) == 8
