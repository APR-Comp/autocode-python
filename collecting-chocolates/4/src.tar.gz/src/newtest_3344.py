
import solution

def test_3344():
	assert solution.Solution().minCost([3, 24, 30],4) == 17
