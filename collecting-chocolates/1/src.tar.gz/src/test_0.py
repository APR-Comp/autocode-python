import solution

def test_0():
	assert solution.Solution().minCost(nums = [20,1,15], x = 5) == 13