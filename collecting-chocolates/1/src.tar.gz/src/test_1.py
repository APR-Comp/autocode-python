import solution

def test_1():
	assert solution.Solution().minCost(nums = [1,2,3], x = 4) == 6