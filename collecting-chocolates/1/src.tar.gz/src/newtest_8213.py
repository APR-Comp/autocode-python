
import solution

def test_8213():
	assert solution.Solution().minCost([7, 73],30) == 44
