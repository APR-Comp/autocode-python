
import solution

def test_7088():
	assert solution.Solution().minCost([4],9) == 4
