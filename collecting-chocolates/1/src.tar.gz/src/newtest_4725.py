
import solution

def test_4725():
	assert solution.Solution().minCost([6],91) == 6
