
import solution

def test_1082():
	assert solution.Solution().minCost([6],5) == 6
