import solution

def test_2():
	assert solution.Solution().minCost(nums = [1], x = 4) == 1