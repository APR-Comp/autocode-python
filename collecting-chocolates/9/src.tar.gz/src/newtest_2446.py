
import solution

def test_2446():
	assert solution.Solution().minCost([6],1) == 6
