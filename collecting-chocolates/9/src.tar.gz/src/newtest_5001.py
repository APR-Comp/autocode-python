
import solution

def test_5001():
	assert solution.Solution().minCost([259],5) == 259
