
import solution

def test_6901():
	assert solution.Solution().minCost([7, 74],59) == 73
