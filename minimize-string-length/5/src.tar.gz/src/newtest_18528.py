
import solution

def test_18528():
	assert solution.Solution().minimizedStringLength("o") == 1
