import solution

def test_4():
	assert solution.Solution().minimizedStringLength(s = "abc") == 3