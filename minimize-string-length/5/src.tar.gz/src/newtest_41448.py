
import solution

def test_41448():
	assert solution.Solution().minimizedStringLength("z") == 1
