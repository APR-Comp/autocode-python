import solution

def test_0():
	assert solution.Solution().minimizedStringLength(s = "aaabc") == 3