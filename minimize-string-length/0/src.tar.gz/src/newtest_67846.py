
import solution

def test_67846():
	assert solution.Solution().minimizedStringLength("j") == 1
