
import solution

def test_47915():
	assert solution.Solution().minimizedStringLength("a") == 1
