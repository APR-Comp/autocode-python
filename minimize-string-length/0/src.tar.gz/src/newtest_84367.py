
import solution

def test_84367():
	assert solution.Solution().minimizedStringLength("l") == 1
