import solution

def test_3():
	assert solution.Solution().minimizedStringLength(s = "aaabc") == 3