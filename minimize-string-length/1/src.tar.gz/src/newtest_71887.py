
import solution

def test_71887():
	assert solution.Solution().minimizedStringLength("rs") == 2
