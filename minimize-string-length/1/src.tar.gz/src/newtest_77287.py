
import solution

def test_77287():
	assert solution.Solution().minimizedStringLength("o") == 1
