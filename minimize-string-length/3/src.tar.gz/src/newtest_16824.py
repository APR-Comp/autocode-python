
import solution

def test_16824():
	assert solution.Solution().minimizedStringLength("ru") == 2
