
import solution

def test_30323():
	assert solution.Solution().minimizedStringLength("dmff") == 3
