import solution

def test_1():
	assert solution.Solution().minimizedStringLength(s = "cbbd") == 3