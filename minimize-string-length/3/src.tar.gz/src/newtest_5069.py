
import solution

def test_5069():
	assert solution.Solution().minimizedStringLength("x") == 1
