
import solution

def test_6881():
	assert solution.Solution().maximumSumQueries([28, 3, 614024154],[29, 8, 2],[[5, 7], [1, 6]]) == [57, 57]
