import solution

def test_3():
	assert solution.Solution().maximumSumQueries(nums1 = [1], nums2 = [1], queries = [[1,1]]) == [2]