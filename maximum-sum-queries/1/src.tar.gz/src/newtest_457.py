
import solution

def test_457():
	assert solution.Solution().maximumSumQueries([2, 7, 4],[2, 8, 734392917],[[5, 3], [8, 4]]) == [15, -1]
