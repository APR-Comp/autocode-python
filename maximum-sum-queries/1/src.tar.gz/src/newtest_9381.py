
import solution

def test_9381():
	assert solution.Solution().maximumSumQueries([7, 6],[8, 2],[[4, 3], [6, 7], [1, 7], [2, 8]]) == [15, 15, 15, 15]
