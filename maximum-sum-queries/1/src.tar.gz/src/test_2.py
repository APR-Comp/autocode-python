import solution

def test_2():
	assert solution.Solution().maximumSumQueries(nums1 = [2,1], nums2 = [2,3], queries = [[3,3]]) == [-1]