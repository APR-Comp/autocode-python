
import solution

def test_7906():
	assert solution.Solution().maximumSumQueries([7, 1],[4, 6],[[8, 4], [2, 6], [5, 4]]) == [-1, -1, 11]
