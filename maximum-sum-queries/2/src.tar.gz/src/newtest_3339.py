
import solution

def test_3339():
	assert solution.Solution().maximumSumQueries([4, 7, 4],[7, 7, 595713972],[[8, 7], [4, 9], [6, 6]]) == [-1, 595713976, 14]
