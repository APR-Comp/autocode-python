
import solution

def test_5353():
	assert solution.Solution().maximumSumQueries([7, 3],[9, 5],[[5, 4], [4, 4], [1, 2]]) == [16, 16, 16]
