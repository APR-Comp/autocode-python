
import solution

def test_6383():
	assert solution.Solution().maximumSumQueries([3, 3, 6],[4, 7, 110782645],[[5, 3], [3, 7]]) == [110782651, 110782651]
