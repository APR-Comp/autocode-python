
import solution

def test_4312():
	assert solution.Solution().maximumSumQueries([8, 8, 843976146],[8, 6, 5],[[5, 5], [5, 4], [6, 8]]) == [843976151, 843976151, 16]
