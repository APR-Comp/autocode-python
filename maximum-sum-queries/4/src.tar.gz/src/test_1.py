import solution

def test_1():
	assert solution.Solution().maximumSumQueries(nums1 = [3,2,5], nums2 = [2,3,4], queries = [[4,4],[3,2],[1,1]]) == [9,9,9]