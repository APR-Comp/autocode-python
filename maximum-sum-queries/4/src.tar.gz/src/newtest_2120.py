
import solution

def test_2120():
	assert solution.Solution().maximumSumQueries([29, 5],[2, 3],[[3, 5], [5, 3]]) == [-1, 8]
