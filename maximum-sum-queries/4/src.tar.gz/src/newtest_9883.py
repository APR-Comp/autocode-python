
import solution

def test_9883():
	assert solution.Solution().maximumSumQueries([7, 3],[7, 4],[[8, 9], [7, 3], [4, 5]]) == [-1, 14, 14]
