import solution

def test_3():
	assert solution.Solution().punishmentNumber(n = 2) == 1