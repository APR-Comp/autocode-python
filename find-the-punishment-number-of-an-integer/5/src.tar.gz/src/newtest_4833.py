
import solution

def test_4833():
	assert solution.Solution().punishmentNumber(7) == 1
