
import solution

def test_8649():
	assert solution.Solution().punishmentNumber(6) == 1
