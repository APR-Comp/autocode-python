
import solution

def test_9185():
	assert solution.Solution().punishmentNumber(7) == 1
