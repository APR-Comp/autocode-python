
import solution

def test_5646():
	assert solution.Solution().punishmentNumber(4) == 1
