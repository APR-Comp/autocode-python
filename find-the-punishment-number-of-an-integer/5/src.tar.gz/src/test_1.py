import solution

def test_1():
	assert solution.Solution().punishmentNumber(n = 37) == 1478