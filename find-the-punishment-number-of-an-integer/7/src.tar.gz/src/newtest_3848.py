
import solution

def test_3848():
	assert solution.Solution().punishmentNumber(4) == 1
