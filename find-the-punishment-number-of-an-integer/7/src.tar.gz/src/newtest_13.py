
import solution

def test_13():
	assert solution.Solution().punishmentNumber(3) == 1
