import solution

def test_2():
	assert solution.Solution().punishmentNumber(n = 1) == 1