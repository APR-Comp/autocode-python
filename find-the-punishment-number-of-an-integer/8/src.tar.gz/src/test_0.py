import solution

def test_0():
	assert solution.Solution().punishmentNumber(n = 10) == 182