
import solution

def test_4058():
	assert solution.Solution().punishmentNumber(182) == 41334
