
import solution

def test_784():
	assert solution.Solution().punishmentNumber(41) == 1478
