
import solution

def test_2204():
	assert solution.Solution().punishmentNumber(139) == 41334
