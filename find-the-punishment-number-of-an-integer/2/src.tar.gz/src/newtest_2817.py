
import solution

def test_2817():
	assert solution.Solution().punishmentNumber(6) == 1
