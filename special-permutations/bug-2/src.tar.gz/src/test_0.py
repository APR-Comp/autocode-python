import solution
def test_0():
	assert solution.Solution().specialPerm(nums = [2, 3, 6]) == 2