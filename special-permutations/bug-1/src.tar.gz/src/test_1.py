import solution
def test_1():
	assert solution.Solution().specialPerm(nums = [1, 4, 3]) == 2