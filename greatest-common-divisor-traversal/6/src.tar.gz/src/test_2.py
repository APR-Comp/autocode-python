import solution

def test_2():
	assert solution.Solution().canTraverseAllPairs(nums = [4,3,12,8])== True