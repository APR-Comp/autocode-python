import solution

def test_1():
	assert solution.Solution().canTraverseAllPairs(nums = [3,9,5])== False