
import solution

def test_772():
	assert solution.Solution().canTraverseAllPairs([77]) == True
