
import solution

def test_758():
	assert solution.Solution().canTraverseAllPairs([5, 9204]) == False
