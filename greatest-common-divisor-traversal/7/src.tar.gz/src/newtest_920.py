
import solution

def test_920():
	assert solution.Solution().canTraverseAllPairs([59, 3, 3, 7]) == False
