
import solution

def test_463():
	assert solution.Solution().canTraverseAllPairs([23]) == True
