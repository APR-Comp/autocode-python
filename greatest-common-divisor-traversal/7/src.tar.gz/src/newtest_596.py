
import solution

def test_596():
	assert solution.Solution().canTraverseAllPairs([9, 3, 7]) == False
