
import solution

def test_664():
	assert solution.Solution().canTraverseAllPairs([4193]) == True
