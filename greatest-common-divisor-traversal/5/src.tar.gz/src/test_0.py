import solution

def test_0():
	assert solution.Solution().canTraverseAllPairs(nums = [2,3,6])== True