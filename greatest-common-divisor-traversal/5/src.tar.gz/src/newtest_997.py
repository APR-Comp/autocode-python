
import solution

def test_997():
	assert solution.Solution().canTraverseAllPairs([9, 8]) == False
