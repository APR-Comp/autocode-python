
import solution

def test_591():
	assert solution.Solution().canTraverseAllPairs([2, 4]) == True
