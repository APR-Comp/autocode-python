
import solution

def test_220():
	assert solution.Solution().canTraverseAllPairs([12]) == True
