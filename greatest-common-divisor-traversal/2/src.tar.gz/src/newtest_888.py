
import solution

def test_888():
	assert solution.Solution().canTraverseAllPairs([7356]) == True
