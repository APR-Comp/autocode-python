
import solution

def test_14334():
	assert solution.Solution().minimumCost("1") == 0
