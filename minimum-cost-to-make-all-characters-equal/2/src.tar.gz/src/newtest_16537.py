
import solution

def test_16537():
	assert solution.Solution().minimumCost("01") == 1
