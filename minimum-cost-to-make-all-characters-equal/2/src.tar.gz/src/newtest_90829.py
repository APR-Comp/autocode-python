
import solution

def test_90829():
	assert solution.Solution().minimumCost("00") == 0
