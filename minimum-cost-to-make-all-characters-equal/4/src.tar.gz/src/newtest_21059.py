
import solution

def test_21059():
	assert solution.Solution().minimumCost("00") == 0
