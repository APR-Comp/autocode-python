
import solution

def test_1583():
	assert solution.Solution().minimumCost("10") == 1
