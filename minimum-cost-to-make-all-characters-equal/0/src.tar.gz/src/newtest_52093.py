
import solution

def test_52093():
	assert solution.Solution().minimumCost("10") == 1
