
import solution

def test_88276():
	assert solution.Solution().minimumCost("0") == 0
