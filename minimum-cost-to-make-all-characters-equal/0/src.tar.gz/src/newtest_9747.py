
import solution

def test_9747():
	assert solution.Solution().minimumCost("1") == 0
