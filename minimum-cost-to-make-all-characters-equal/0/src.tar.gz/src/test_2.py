import solution

def test_2():
	assert solution.Solution().minimumCost(s = "000") == 0