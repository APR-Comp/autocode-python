
import solution

def test_69526():
	assert solution.Solution().minimumCost("0") == 0
