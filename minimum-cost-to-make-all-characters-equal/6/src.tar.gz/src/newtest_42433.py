
import solution

def test_42433():
	assert solution.Solution().minimumCost("111") == 0
