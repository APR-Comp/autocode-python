import solution

def test_0():
	assert solution.Solution().minimumCost(s = "0011") == 2