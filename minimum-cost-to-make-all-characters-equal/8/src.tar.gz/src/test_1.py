import solution

def test_1():
	assert solution.Solution().minimumCost(s = "010101") == 9