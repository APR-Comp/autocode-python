
import solution

def test_7760():
	assert solution.Solution().maxIncreasingCells([[64, 430, 446, 983], [68, 29, 8, 56]]) == 5
