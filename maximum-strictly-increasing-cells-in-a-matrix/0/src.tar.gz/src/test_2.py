import solution

def test_2():
	assert solution.Solution().maxIncreasingCells(mat = [[3,1,6],[-9,5,7]]) == 4