
import solution

def test_3342():
	assert solution.Solution().maxIncreasingCells([[1, 2, 8], [9, 5, 606], [8, 1, 598]]) == 5
