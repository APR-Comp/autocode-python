
import solution

def test_6955():
	assert solution.Solution().maxIncreasingCells([[2, 8, 35], [1, 32, 199]]) == 5
