import solution

def test_3():
	assert solution.Solution().maxIncreasingCells(mat = [[-1,-2]]) == 2