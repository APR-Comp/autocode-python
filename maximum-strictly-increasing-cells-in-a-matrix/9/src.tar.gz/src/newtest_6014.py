
import solution

def test_6014():
	assert solution.Solution().maxIncreasingCells([[3, 2, 68], [51, 32, 583]]) == 4
