
import solution

def test_3814():
	assert solution.Solution().maxIncreasingCells([[84, 3], [8, 62], [6, 703], [4, 414]]) == 6
