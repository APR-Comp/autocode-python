
import solution

def test_6040():
	assert solution.Solution().maxIncreasingCells([[18, 1], [6, 600], [4, 309]]) == 3
