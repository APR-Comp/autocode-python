import solution

def test_1():
	assert solution.Solution().maxIncreasingCells(mat = [[1,1],[1,1]]) == 1