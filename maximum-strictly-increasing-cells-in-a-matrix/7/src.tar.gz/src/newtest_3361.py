
import solution

def test_3361():
	assert solution.Solution().maxIncreasingCells([[3, 4, 6, 2], [7, 981, 739, 133], [9, 368, 577, 368], [5, 604, 125, 760]]) == 9
