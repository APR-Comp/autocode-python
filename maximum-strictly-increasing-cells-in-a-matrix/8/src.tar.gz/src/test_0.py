import solution

def test_0():
	assert solution.Solution().maxIncreasingCells(mat = [[3,1],[3,4]]) == 2