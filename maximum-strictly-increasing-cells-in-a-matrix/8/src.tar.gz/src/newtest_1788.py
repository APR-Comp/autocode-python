
import solution

def test_1788():
	assert solution.Solution().maxIncreasingCells([[1, 582], [8, 25], [2, 535]]) == 6
