
import solution

def test_5729():
	assert solution.Solution().maxIncreasingCells([[8, 1, 38], [99, 5, 586]]) == 4
