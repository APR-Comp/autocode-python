
import solution

def test_4387():
	assert solution.Solution().maxIncreasingCells([[7, 7, 313], [4, 1, 5]]) == 4
