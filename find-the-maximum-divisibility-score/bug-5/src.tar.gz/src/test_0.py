import solution
def test_0():
	assert solution.Solution().maxDivScore(nums = [4, 7, 9, 3, 9], divisors = [5, 2, 3]) == 3