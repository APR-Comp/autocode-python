import solution
def test_2():
	assert solution.Solution().maxDivScore(nums = [12], divisors = [10, 16]) == 10