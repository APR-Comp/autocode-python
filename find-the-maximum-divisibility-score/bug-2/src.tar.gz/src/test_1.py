import solution
def test_1():
	assert solution.Solution().maxDivScore(nums = [20, 14, 21, 10], divisors = [5, 7, 5]) == 5